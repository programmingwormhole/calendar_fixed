class DatePickerConfig {
  final DateTime? firstDate;
  final DateTime? lastDate;
  final DateTime? initialDate;

  DatePickerConfig({this.firstDate, this.lastDate, this.initialDate});
}
